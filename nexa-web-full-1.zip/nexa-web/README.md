# Nexa Agent (Web UI)

Coding/personal assistant agent yang jalan di browser, pakai model AI apapun lewat
[OpenRouter](https://openrouter.ai). Dibangun di atas `agent.py` (logic inti, sama
dengan versi CLI) + `webui.py` (server web ringan, no-framework, jalan di browser HP).

## Fitur

- Loop agentic: baca/tulis/edit file, jalankan command shell, cari kode di banyak file.
- Browsing: `web_search`, `bing_search`, `google_search`, `fetch_url`, `wikipedia_lookup`.
- YouTube: `youtube_search`, `youtube_info` (cari & ambil info video, tanpa API key).
- **Gmail**: `gmail_read` (baca/cari email), `gmail_send` (kirim email) — lihat
  setup di bawah.
- **Google Calendar**: `calendar_create_event` (bikin event baru, misal jadwal
  pertandingan/meeting) — pakai OAuth & token yang sama dengan Gmail, lihat
  setup di bawah.
- **Google Drive**: `drive_list_files` (cari/list file), `drive_read_file`
  (baca isi Google Docs/Sheets/Slides atau file teks) — read-only, pakai OAuth
  & token yang sama dengan Gmail/Calendar.
- **Lihat Gambar**: kirim foto lewat tombol 📎 di web UI, agent otomatis pakai
  model vision gratis untuk menganalisa/menjawab soal isi gambar (model utama
  kebanyakan text-only, jadi otomatis dialihkan saat ada gambar terlampir).
- **Marketplace (Shopee/Tokopedia)**: `marketplace_search` — cari rekomendasi
  produk lewat web search (bukan API resmi), kasih judul, perkiraan harga, dan
  link ke halaman produk. **Harga bisa tidak akurat/update** karena diambil
  dari snippet pencarian, bukan API resmi marketplace — selalu cek harga final
  di link sebelum beli. Tidak bisa mengambil gambar produk dan tidak bisa
  melakukan transaksi apapun (cuma cari, tidak ada akses akun/pembayaran).
- **Spotify**: `spotify_search` — cari lagu/artist/album/playlist (search
  publik, tidak perlu login akun Spotify) — lihat setup di bawah. **Tidak bisa
  kontrol playback** (play/pause/skip); itu butuh Spotify Premium + login
  OAuth user terpisah, di luar cakupan saat ini.
- Approval system: aksi yang mengubah sesuatu (tulis file, command shell, kirim
  email) selalu minta izin eksplisit dulu sebelum dieksekusi. **Catatan**:
  `calendar_create_event` adalah pengecualian sengaja — auto-approve, lihat
  bagian "Catatan keamanan" di bawah.

## Setup Dasar

```bash
pip install -r requirements.txt
export OPENROUTER_API_KEY="sk-or-xxxx"
python webui.py
```

Buka `http://localhost:8080` di browser.

## Setup Gmail & Google Calendar & Drive

Fitur Gmail, Calendar, dan Drive pakai OAuth resmi Google, **bukan** password —
agent tidak pernah melihat/menyimpan password Google kamu, hanya token akses
terbatas (baca+kirim email, baca+buat event kalender, baca-saja Drive — tidak
bisa hapus email, akses lain, atau upload/edit/hapus file Drive). Setup-nya
**satu kali untuk tiga fitur sekaligus** (satu credentials.json, satu login,
satu token), tidak perlu OAuth terpisah untuk masing-masing.

> **Kenapa harus bikin OAuth Client ID sendiri, bukan dipasang sekali untuk semua
> orang?** Karena ini project open source. Kalau satu Client ID dipakai bareng-bareng
> oleh semua orang yang clone repo ini, itu artinya satu credential dibagi ke banyak
> pihak tak dikenal — bukan praktik yang aman, dan Google sendiri akan menganggap
> app dengan pola pemakaian seperti itu mencurigakan. Bikin Client ID sendiri itu
> gratis dan cuma butuh 2-3 menit.

### Langkah-langkah

1. Buka [Google Cloud Console](https://console.cloud.google.com/) → buat project
   baru (nama bebas).
2. Di **APIs & Services → Library**, enable **Gmail API**, **Google Calendar
   API**, DAN **Google Drive API** (tiga-tiganya, satu-satu).
3. Di **APIs & Services → OAuth consent screen**:
   - Pilih **External**.
   - Isi nama app (bebas) dan email kamu.
   - Di bagian **Test users**, tambahkan alamat Gmail kamu sendiri.
4. Di **APIs & Services → Credentials** → **Create Credentials** → **OAuth client ID**:
   - Application type: **Desktop app**.
   - Kasih nama bebas → **Create**.
5. Download file JSON-nya, **rename jadi `credentials.json`**, taruh sejajar
   dengan `agent.py` (folder root project ini).
6. Jalankan agent seperti biasa. Begitu pertama kali model memanggil
   `gmail_read`/`gmail_send`/`calendar_create_event`/`drive_list_files`/
   `drive_read_file`, browser akan otomatis terbuka minta kamu login & approve
   akses Gmail, Calendar, **dan** Drive sekaligus (satu layar consent, tiga
   izin). Setelah itu token disimpan di `token_google.json` (lokal), jadi
   tidak perlu login ulang tiap menjalankan agent.

`credentials.json` dan `token_google.json` sudah otomatis di-`.gitignore` —
**jangan pernah commit kedua file ini ke repo**, siapapun yang punya
`token_google.json` kamu bisa baca/kirim email, bikin event di kalender, dan
baca isi file Drive kamu.

### Catatan keamanan Gmail, Calendar & Drive

- Scope yang dipakai sengaja dibatasi ke `gmail.readonly` (baca email),
  `gmail.send` (kirim email), `calendar.events` (baca+buat event), dan
  `drive.readonly` (baca-saja Drive) — agent **tidak bisa** menghapus email,
  mengubah label, menghapus/mengubah kalender itu sendiri, atau
  upload/edit/hapus file apapun di Drive kamu.
- `gmail_send` **selalu** minta approval kamu dulu sebelum benar-benar mengirim,
  termasuk preview lengkap penerima/subjek/isi — tidak ada mode "always allow"
  silent untuk tool ini.
- `calendar_create_event` **auto-approve** (langsung dieksekusi tanpa konfirmasi
  manual) — ini pilihan sadar karena efeknya hanya ke kalender pribadi kamu
  sendiri (bukan mengirim apapun ke pihak luar) dan event yang salah mudah
  dihapus/diedit lagi nanti. Trade-off-nya: kalau model salah menafsirkan
  tanggal/jam (misal dari hasil pencarian web yang ambigu), event langsung
  masuk ke kalendermu tanpa kamu sempat cek draft dulu seperti email. Kalau mau
  fitur ini juga minta approval manual, hapus `"calendar_create_event"` dari set
  `SAFE_TOOLS` di `agent.py`.
- `drive_list_files` dan `drive_read_file` murni read-only — gak ada cara
  upload, edit, atau hapus file lewat scope `drive.readonly`. `drive_read_file`
  cuma bisa baca Google Docs/Sheets/Slides (lewat export) dan file teks biasa;
  file biner (gambar, PDF, video) tidak didukung.
- Kalau mau cabut akses sewaktu-waktu: hapus `token_google.json`, atau cabut
  akses dari [myaccount.google.com/permissions](https://myaccount.google.com/permissions).
- Jangan jalankan agent ini dengan akun Google utama/kerja kalau kamu belum
  yakin 100% sama prompt yang kamu kasih — selalu baca draft email sebelum
  approve kirim, dan cek kalender setelah minta agent menambahkan event.

## Struktur Project

```
nexa-web/
├── agent.py         # Logic inti: tools, system prompt, komunikasi OpenRouter
├── webui.py          # Server web (http.server bawaan Python, no framework)
├── gmail_auth.py      # Modul OAuth Google (Gmail + Calendar + Drive, terpisah, lazy-imported)
├── spotify_auth.py    # Modul auth Spotify (Client Credentials Flow, search-only)
├── requirements.txt
├── .gitignore         # credentials.json & token_*.json otomatis di-ignore
└── README.md
```

## Roadmap

- [x] Gmail (read + send)
- [x] Google Calendar (create event)
- [ ] Google Calendar (read/list event)
- [x] Google Drive (list + read file, read-only)
- [ ] Google Drive (upload + create file)
- [x] Marketplace search Shopee/Tokopedia (web search based, tanpa API resmi,
      tanpa gambar produk)
- [x] Spotify (search lagu/artist/album/playlist, tanpa kontrol playback)
- [ ] Spotify (playback control — butuh Premium + OAuth user, belum dikerjakan)

## Catatan tentang Marketplace Search

`marketplace_search` **tidak butuh setup OAuth apapun** (beda dari Gmail/
Calendar/Drive) — dia cuma pakai web search biasa yang difilter ke domain
Shopee/Tokopedia. Karena bukan API resmi:

- Harga yang ditampilkan adalah **perkiraan** dari snippet hasil pencarian,
  bisa sudah berubah/tidak akurat. Selalu cek harga final di link sebelum beli.
- **Tidak ada gambar produk** — kalau butuh visual produk, itu di luar
  kemampuan tool ini saat ini.
- Tidak ada akses ke akun Shopee/Tokopedia kamu (tidak bisa checkout, lihat
  pesanan, dll) — kalau butuh itu, perlu API resmi Shopee Open Platform /
  Tokopedia Developer API dengan setup terpisah (akun seller + app registration).

## Setup Spotify

Fitur Spotify cuma untuk **search** (lagu/artist/album/playlist), pakai
**Client Credentials Flow** — beda dari Gmail/Calendar/Drive yang minta kamu
login & approve lewat browser. Untuk search, **tidak ada login user sama
sekali**; agent cuma butuh "identitas aplikasi" (Client ID + Secret) yang
gratis dibuat sendiri.

### Langkah-langkah

1. Buka [Spotify for Developers Dashboard](https://developer.spotify.com/dashboard)
   → login pakai akun Spotify kamu (Free maupun Premium, dua-duanya bisa).
2. Klik **Create app** → isi nama & deskripsi app (bebas).
3. Redirect URI wajib diisi walau tidak benar-benar dipakai di flow ini
   (syarat form Spotify) → isi `http://localhost:8080/callback`.
4. Centang **Web API** di bagian "Which API/SDKs are you planning to use?".
5. Setelah app dibuat, buka **Settings** → catat **Client ID**, klik **View
   client secret** untuk lihat **Client Secret**.
6. Set sebagai environment variable sebelum jalanin agent:
   ```bash
   export SPOTIFY_CLIENT_ID="xxxxxxxx"
   export SPOTIFY_CLIENT_SECRET="xxxxxxxx"
   ```

### Catatan keamanan & limitasi Spotify

- Client ID/Secret **bukan** password akun Spotify kamu — cuma identitas
  aplikasi, dan secara desain Client Credentials Flow tidak bisa mengakses
  data user (playlist pribadi, riwayat dengar, dll), cuma search publik.
- **Tidak bisa kontrol playback** (play/pause/skip) sama sekali lewat tool
  ini — itu butuh flow OAuth user (Authorization Code Flow) yang berbeda DAN
  Spotify Premium (Spotify Web API menolak request playback untuk akun Free,
  ini limitasi dari Spotify, bukan dari kode project ini).
- Kalau `SPOTIFY_CLIENT_ID`/`SPOTIFY_CLIENT_SECRET` belum di-set, tool akan
  mengembalikan pesan error yang jelas, bukan crash.
