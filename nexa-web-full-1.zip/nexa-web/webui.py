#!/usr/bin/env python3
"""
Web UI untuk Mini Coding Agent - buka di browser HP
Jalankan: python webui.py
Buka: http://localhost:8080
"""

import os, sys, json, threading, queue, time
from pathlib import Path
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse
import agent as core

# ======== STATE ========
sessions = {}

class Session:
    def __init__(self):
        self.messages = core.build_system_messages()
        self.cwd = os.getcwd()
        self.current_model = core.OPENROUTER_MODEL
        self.always_approved = set()
        self.usage_stats = {"prompt_tokens":0,"completion_tokens":0,"total_tokens":0,"cost_usd":0.0,"api_calls":0}
        self.log = []  # list of {type, text}
        self.running = False
        self.pending_tool = None  # {fn_name, args, answer_queue}

sess = Session()

def add_log(type_, text, extra=None):
    entry = {"type": type_, "text": text, "ts": time.strftime("%H:%M:%S")}
    if extra:
        entry["extra"] = extra
    sess.log.append(entry)

def run_agent(user_text, image_data_url=None):
    sess.running = True
    if image_data_url:
        content = []
        if user_text:
            content.append({"type": "text", "text": user_text})
        else:
            content.append({"type": "text", "text": "Tolong lihat gambar ini."})
        content.append({"type": "image_url", "image_url": {"url": image_data_url}})
        sess.messages.append({"role": "user", "content": content})
    else:
        sess.messages.append({"role": "user", "content": user_text})
    try:
        loop_count = 0
        while loop_count < core.MAX_TOOL_ITERATIONS:
            loop_count += 1
            add_log("thinking", "Berpikir...")
            try:
                data, used_model = core.call_model(sess.messages, sess.current_model)
            except Exception as e:
                add_log("error", f"Error model: {e}")
                break
            sess.current_model = used_model
            core.update_usage_stats(sess.usage_stats, data)
            if "choices" not in data or not data["choices"]:
                err = data.get("error", {})
                add_log("error", f"API error: {err.get('message', str(data))}")
                break
            choice = data["choices"][0]
            msg = choice["message"]
            sess.messages.append(msg)
            tool_calls = msg.get("tool_calls")
            if not tool_calls:
                content = msg.get("content") or "(tidak ada respons)"
                add_log("agent", content)
                break
            if msg.get("content"):
                add_log("think", msg['content'])
            for tc in tool_calls:
                fn_name = tc["function"]["name"]
                try:
                    args = json.loads(tc["function"]["arguments"])
                except:
                    args = {}
                auto = False
                if fn_name in core.SAFE_TOOLS:
                    auto = True
                elif fn_name == "run_command" and core.is_safe_command(args.get("command","")):
                    auto = True
                elif fn_name in sess.always_approved:
                    auto = True
                if auto:
                    decision = "yes"
                else:
                    desc = core.describe_tool_call(fn_name, args)
                    detail = json.dumps(args, ensure_ascii=False)
                    aq = queue.Queue()
                    sess.pending_tool = {"fn_name": fn_name, "desc": desc, "detail": detail, "aq": aq}
                    add_log("approval", desc)
                    try:
                        decision = aq.get(timeout=300)
                    except queue.Empty:
                        decision = "no"
                        add_log("info", "Timeout, ditolak otomatis.")
                    sess.pending_tool = None
                    if decision == "always":
                        sess.always_approved.add(fn_name)
                if decision == "no":
                    result = "DITOLAK oleh user."
                    add_log("info", f"Ditolak: {fn_name}")
                else:
                    impl = core.TOOL_IMPL.get(fn_name)
                    if impl is None:
                        result = f"ERROR: tool '{fn_name}' tidak dikenal."
                    else:
                        old_cwd = os.getcwd()
                        try:
                            os.chdir(sess.cwd)
                            result = impl(**args)
                        except Exception as e:
                            result = f"ERROR: {e}"
                        finally:
                            os.chdir(old_cwd)
                    preview = str(result)[:600]
                    # Cek kalau ini hasil youtube_search — kirim extra thumbnail
                    extra = None
                    if fn_name == "youtube_search":
                        import re as _re
                        vids = []
                        for m in _re.finditer(r'URL: (https://www\.youtube\.com/watch\?v=([\w-]+))', str(result)):
                            vid_id = m.group(2)
                            vids.append({"vid_id": vid_id, "thumb": f"https://img.youtube.com/vi/{vid_id}/mqdefault.jpg", "url": m.group(1)})
                        if vids:
                            extra = {"type": "youtube_thumbs", "videos": vids[:5]}
                    add_log("result", f"{fn_name}:\n{preview}", extra=extra)
                sess.messages.append({"role":"tool","tool_call_id":tc["id"],"content":str(result)})
    finally:
        sess.running = False
        add_log("done", "Selesai.")

HTML = r"""<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>Nexa Agent</title>
<style>
:root{
  --bg:#0a0a0f;
  --surface:#111118;
  --surface2:#18181f;
  --border:#ffffff0f;
  --accent:#e94560;
  --accent2:#7c3aed;
  --text:#f0f0f5;
  --muted:#555566;
  --green:#22c55e;
  --yellow:#f59e0b;
  --mono:'SF Mono',ui-monospace,monospace;
}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{height:100%;overflow:hidden}
body{font-family:-apple-system,system-ui,sans-serif;background:var(--bg);color:var(--text);display:flex;flex-direction:column;height:100dvh}

/* HEADER */
#hdr{
  display:flex;align-items:center;justify-content:space-between;
  padding:14px 16px;
  background:var(--surface);
  border-bottom:1px solid var(--border);
  flex-shrink:0;
}
#hdr-left{display:flex;align-items:center;gap:10px}
#hdr-dot{width:8px;height:8px;border-radius:50%;background:var(--green);box-shadow:0 0 8px var(--green);flex-shrink:0}
#hdr-title{font-size:16px;font-weight:600;letter-spacing:-.3px}
#hdr-title span{color:var(--accent)}
#hdr-model{font-size:11px;color:var(--muted);font-family:var(--mono);max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

/* LOG */
#log{
  flex:1;overflow-y:auto;overflow-x:hidden;
  padding:16px 14px;
  display:flex;flex-direction:column;gap:10px;
  scroll-behavior:smooth;
}
#log::-webkit-scrollbar{width:3px}
#log::-webkit-scrollbar-track{background:transparent}
#log::-webkit-scrollbar-thumb{background:var(--border);border-radius:2px}

/* MESSAGES */
.msg{
  max-width:88%;
  padding:10px 13px;
  border-radius:14px;
  font-size:14px;
  line-height:1.6;
  word-break:break-word;
  animation:fadeUp .2s ease;
}
@keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}

.msg.user{
  align-self:flex-end;
  background:linear-gradient(135deg,#1e3a6e,#162d58);
  border:1px solid #ffffff12;
  border-bottom-right-radius:4px;
  color:#e8eeff;
}
.msg.agent{
  align-self:flex-start;
  background:var(--surface2);
  border:1px solid var(--border);
  border-bottom-left-radius:4px;
  white-space:pre-wrap;
}
.msg.think{
  align-self:flex-start;
  color:var(--muted);
  font-size:13px;
  font-style:italic;
  padding:4px 0;
  max-width:100%;
  background:none;
}
.msg.thinking{
  align-self:flex-start;
  color:var(--muted);
  font-size:13px;
  display:flex;align-items:center;gap:6px;
  padding:4px 0;
  background:none;
}
.msg.thinking::before{
  content:'';width:14px;height:14px;border-radius:50%;
  border:2px solid var(--muted);border-top-color:var(--accent);
  animation:spin .8s linear infinite;display:inline-block;flex-shrink:0;
}
@keyframes spin{to{transform:rotate(360deg)}}

.msg.result{
  align-self:flex-start;
  background:#0d1117;
  border:1px solid #30363d;
  border-left:3px solid var(--accent2);
  border-radius:8px;
  font-family:var(--mono);
  font-size:12px;
  color:#c9d1d9;
  max-width:100%;
  white-space:pre-wrap;
  overflow-x:auto;
}
.result-header{
  font-size:11px;color:var(--accent2);
  margin-bottom:4px;font-weight:600;
  letter-spacing:.3px;text-transform:uppercase;
}
.msg.error{
  align-self:flex-start;
  background:#1a0505;
  border:1px solid #e9456033;
  border-left:3px solid var(--accent);
  border-radius:8px;
  color:#ffaaaa;
  font-size:13px;
}
.msg.done{
  align-self:center;
  font-size:12px;color:var(--green);
  background:#0a1a0f;border:1px solid #22c55e22;
  border-radius:20px;padding:5px 14px;
}
.msg.info{
  align-self:center;font-size:12px;
  color:var(--muted);padding:4px 0;background:none;
}
.msg.approval{
  align-self:flex-start;
  background:#1a1205;
  border:1px solid #f59e0b33;
  border-left:3px solid var(--yellow);
  border-radius:8px;
  color:#fde68a;
  font-size:13px;
  max-width:100%;
}

/* APPROVAL BAR */
#approval-bar{
  background:var(--surface);
  border-top:1px solid var(--border);
  padding:12px 14px;
  display:none;
  flex-shrink:0;
}
#approval-desc{
  font-size:13px;color:var(--yellow);
  margin-bottom:10px;line-height:1.5;
  font-family:var(--mono);
}
.btns{display:flex;gap:8px}
.btns button{
  flex:1;padding:10px 8px;border:none;
  border-radius:10px;font-size:13px;font-weight:600;
  cursor:pointer;letter-spacing:.2px;transition:opacity .15s;
}
.btns button:active{opacity:.7}
.btn-yes{background:#14532d;color:#86efac;border:1px solid #22c55e33}
.btn-no{background:#450a0a;color:#fca5a5;border:1px solid #ef444433}
.btn-always{background:#1e1b4b;color:#a5b4fc;border:1px solid #6366f133}

/* COST BAR */
#cost-bar{
  padding:5px 16px;
  font-size:11px;color:var(--muted);
  font-family:var(--mono);
  background:var(--surface);
  border-top:1px solid var(--border);
  flex-shrink:0;
  display:flex;gap:12px;
}

/* INPUT */
#input-area{
  background:var(--surface);
  border-top:1px solid var(--border);
  padding:10px 12px;
  flex-shrink:0;
}
#input-row{
  display:flex;gap:8px;align-items:flex-end;
}
#img-preview{
  display:flex;align-items:center;gap:8px;
  margin-bottom:8px;
  background:var(--surface2);
  border:1px solid var(--border);
  border-radius:10px;
  padding:6px 10px;
}
#img-preview-thumb{
  width:36px;height:36px;object-fit:cover;
  border-radius:6px;flex-shrink:0;
}
#img-preview-remove{
  margin-left:auto;background:none;border:none;
  color:var(--muted);font-size:14px;cursor:pointer;
  padding:4px 8px;
}
#attach-btn{
  background:var(--surface2);border:1px solid var(--border);
  color:var(--text);border-radius:12px;width:44px;height:44px;
  font-size:18px;cursor:pointer;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  transition:opacity .15s;
}
#attach-btn:active{opacity:.7}
#inp{
  flex:1;background:var(--surface2);
  border:1px solid var(--border);
  color:var(--text);border-radius:12px;
  padding:11px 14px;font-size:14px;
  resize:none;min-height:44px;max-height:120px;
  font-family:inherit;line-height:1.5;
  transition:border-color .15s;
}
#inp:focus{outline:none;border-color:#e9456055}
#inp::placeholder{color:var(--muted)}
#send-btn{
  background:var(--accent);border:none;color:#fff;
  border-radius:12px;width:44px;height:44px;
  font-size:18px;cursor:pointer;flex-shrink:0;
  display:flex;align-items:center;justify-content:center;
  transition:opacity .15s;
}
#send-btn:disabled{background:var(--surface2);color:var(--muted);cursor:not-allowed}
#send-btn:active:not(:disabled){opacity:.7}

/* CHAT IMAGE */
.msg-img{max-width:100%;border-radius:10px;margin-top:6px;display:block}

/* AUTOCOMPLETE */
#autocomplete{
  display:none;
  position:absolute;bottom:100%;left:0;right:0;
  background:var(--surface2);
  border:1px solid var(--border);
  border-radius:12px 12px 0 0;
  overflow:hidden;
  margin-bottom:1px;
}
.ac-item{
  display:flex;align-items:center;gap:10px;
  padding:10px 14px;cursor:pointer;
  border-bottom:1px solid var(--border);
  transition:background .1s;
}
.ac-item:last-child{border-bottom:none}
.ac-item:hover,.ac-item.active{background:#ffffff08}
.ac-cmd{font-family:var(--mono);font-size:13px;color:var(--accent);font-weight:600}
.ac-desc{font-size:12px;color:var(--muted)}

/* YOUTUBE GRID */
.yt-grid{display:flex;gap:8px;flex-wrap:nowrap;overflow-x:auto;margin-top:10px;padding-bottom:4px}
.yt-grid::-webkit-scrollbar{height:3px}
.yt-grid::-webkit-scrollbar-thumb{background:var(--border);border-radius:2px}
.yt-thumb img{
  width:160px;height:90px;object-fit:cover;
  border-radius:8px;border:1px solid var(--border);
  display:block;transition:opacity .15s;flex-shrink:0;
}
.yt-thumb:active img{opacity:.7}
</style>
</head>
<body>
<div id="hdr">
  <div id="hdr-left">
    <div id="hdr-dot"></div>
    <div id="hdr-title">Nexa <span>Agent</span></div>
  </div>
  <div id="hdr-model">loading...</div>
</div>
<div id="log"></div>
<div id="approval-bar">
  <div id="approval-desc"></div>
  <div class="btns">
    <button class="btn-yes" onclick="answer('yes')">✓ Yes</button>
    <button class="btn-no" onclick="answer('no')">✕ No</button>
    <button class="btn-always" onclick="answer('always')">∞ Always</button>
  </div>
</div>
<div id="cost-bar">
  <span id="stat-tokens">0 tokens</span>
  <span id="stat-cost">$0.0000</span>
</div>
<div id="input-area" style="position:relative">
  <div id="autocomplete"></div>
  <div id="img-preview" style="display:none">
    <img id="img-preview-thumb">
    <button id="img-preview-remove" onclick="removeImage()">✕</button>
  </div>
  <div id="input-row">
    <button id="attach-btn" onclick="document.getElementById('file-inp').click()">📎</button>
    <input type="file" id="file-inp" accept="image/*" style="display:none" onchange="onFileSelected(this)">
    <textarea id="inp" placeholder="Ketik perintah atau / untuk perintah cepat..." rows="1" onkeydown="onKey(event)" oninput="onInput(this)"></textarea>
    <button id="send-btn" onclick="send()">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
    </button>
  </div>
</div>
<script>
let lastLen=0,polling=false,thinkingEl=null,pendingImage=null;

const COMMANDS=[
  {cmd:'/help',desc:'Tampilkan bantuan'},
  {cmd:'/cari ',desc:'Cari di web'},
  {cmd:'/buka ',desc:'Buka URL halaman web'},
  {cmd:'/youtube ',desc:'Cari video YouTube'},
  {cmd:'/baca ',desc:'Baca file di proyek'},
  {cmd:'/jalankan ',desc:'Jalankan perintah shell'},
  {cmd:'/daftar ',desc:'Lihat isi folder'},
  {cmd:'/email ',desc:'Baca/cari email Gmail'},
  {cmd:'/kirimemail ',desc:'Kirim email lewat Gmail'},
  {cmd:'/kalender ',desc:'Tambah event ke Google Calendar'},
  {cmd:'/drive ',desc:'Cari/baca file Google Drive'},
  {cmd:'/spotify ',desc:'Cari lagu/artist/album/playlist'},
  {cmd:'/belanja ',desc:'Cari produk Shopee/Tokopedia'},
  {cmd:'/model',desc:'Info model yang dipakai'},
  {cmd:'/reset',desc:'Reset sesi percakapan'},
];

function autoResize(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,120)+'px'}

function onKey(e){
  const ac=document.getElementById('autocomplete');
  if(ac.style.display!=='none'){
    const items=ac.querySelectorAll('.ac-item');
    const active=ac.querySelector('.ac-item.active');
    if(e.key==='ArrowDown'){e.preventDefault();
      const next=active?active.nextElementSibling||items[0]:items[0];
      if(active)active.classList.remove('active');
      if(next)next.classList.add('active');return;
    }
    if(e.key==='ArrowUp'){e.preventDefault();
      const prev=active?active.previousElementSibling||items[items.length-1]:items[items.length-1];
      if(active)active.classList.remove('active');
      if(prev)prev.classList.add('active');return;
    }
    if(e.key==='Tab'||e.key==='Enter'){
      const sel=ac.querySelector('.ac-item.active')||items[0];
      if(sel&&e.key==='Tab'){e.preventDefault();applyCmd(sel.dataset.cmd);return;}
    }
    if(e.key==='Escape'){hideAC();return;}
  }
  if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();send();}
}

function onInput(el){
  autoResize(el);
  const v=el.value;
  if(v.startsWith('/')){
    const matches=COMMANDS.filter(c=>c.cmd.startsWith(v));
    if(matches.length){showAC(matches,v);}else{hideAC();}
  }else{hideAC();}
}

function showAC(matches,val){
  const ac=document.getElementById('autocomplete');
  ac.innerHTML='';
  matches.forEach((m,i)=>{
    const d=document.createElement('div');
    d.className='ac-item'+(i===0?' active':'');
    d.dataset.cmd=m.cmd;
    d.innerHTML=`<span class="ac-cmd">${m.cmd}</span><span class="ac-desc">${m.desc}</span>`;
    d.onclick=()=>applyCmd(m.cmd);
    ac.appendChild(d);
  });
  ac.style.display='block';
}

function hideAC(){document.getElementById('autocomplete').style.display='none';}

function applyCmd(cmd){
  const inp=document.getElementById('inp');
  inp.value=cmd;
  inp.focus();
  hideAC();
  autoResize(inp);
}

function onFileSelected(input){
  const file=input.files[0];
  if(!file)return;
  if(file.size>8*1024*1024){
    alert('Gambar maksimal 8MB.');
    input.value='';
    return;
  }
  const reader=new FileReader();
  reader.onload=()=>{
    pendingImage=reader.result;
    document.getElementById('img-preview-thumb').src=pendingImage;
    document.getElementById('img-preview').style.display='flex';
  };
  reader.readAsDataURL(file);
  input.value='';
}

function removeImage(){
  pendingImage=null;
  document.getElementById('img-preview').style.display='none';
  document.getElementById('img-preview-thumb').src='';
}

function send(){
  const inp=document.getElementById('inp');
  const txt=inp.value.trim();
  if(!txt&&!pendingImage)return;
  hideAC();
  addMsg('user',txt||'(gambar)',pendingImage?{type:'image',src:pendingImage}:null);
  inp.value='';inp.style.height='44px';
  document.getElementById('send-btn').disabled=true;
  const payload={text:txt};
  if(pendingImage)payload.image=pendingImage;
  fetch('/send',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  removeImage();
  if(!polling)startPoll();
}

function answer(d){
  fetch('/answer',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({decision:d})});
  document.getElementById('approval-bar').style.display='none';
}

function removeThinking(){
  if(thinkingEl){thinkingEl.remove();thinkingEl=null;}
}

function addMsg(type,raw,extra){
  const log=document.getElementById('log');
  let text=(raw||'').replace(/^[🤖💭⏳✅❌▶️⚠️ℹ️🔐]+\s*/,'');

  if(type==='thinking'){
    removeThinking();
    const d=document.createElement('div');
    d.className='msg thinking';
    d.textContent='Berpikir...';
    log.appendChild(d);
    thinkingEl=d;
    log.scrollTop=log.scrollHeight;
    return;
  }

  removeThinking();

  const d=document.createElement('div');
  d.className='msg '+type;

  if(type==='user'&&extra&&extra.type==='image'){
    const img=document.createElement('img');
    img.className='msg-img';img.src=extra.src;
    d.appendChild(img);
    if(text&&text!=='(gambar)'){
      const p=document.createElement('div');
      p.style.marginTop='6px';p.textContent=text;
      d.appendChild(p);
    }
    log.appendChild(d);
    log.scrollTop=log.scrollHeight;
    return;
  }

  if(type==='agent'){
    text=text
      .replace(/\*\*(.+?)\*\*/g,'$1')
      .replace(/\*(.+?)\*/g,'$1')
      .replace(/#{1,6}\s+(.+)/g,'$1')
      .replace(/\[([^\]]+)\]\([^)]+\)/g,'$1')
      .replace(/【[^】]*】/g,'')
      // Hapus baris separator tabel |---|---|
      .replace(/^\|[-| :]+\|.*$/gm,'')
      // Konversi baris tabel | a | b | c | → bullet bersih
      .replace(/^\|(.+)\|$/gm,(_,inner)=>{
        const cells=inner.split('|').map(s=>s.trim()).filter(Boolean);
        if(cells.length===0)return'';
        // Baris pertama (header) atau baris data — format sebagai bullet
        return'• '+cells.join(' — ');
      })
      .replace(/^[-*]\s+/gm,'• ')
      // Hapus multiple blank lines
      .replace(/\n{3,}/g,'\n\n')
      .trim();
    d.textContent=text;
  } else if(type==='result'){
    const nl=text.indexOf('\n');
    const header=nl>-1?text.slice(0,nl):text;
    const body=nl>-1?text.slice(nl+1):'';
    d.innerHTML='<div class="result-header">'+esc(header)+'</div>'+esc(body);
    // YouTube thumbnails
    if(extra&&extra.type==='youtube_thumbs'&&extra.videos.length){
      const grid=document.createElement('div');
      grid.className='yt-grid';
      extra.videos.forEach(v=>{
        const a=document.createElement('a');
        a.href=v.url;a.target='_blank';a.className='yt-thumb';
        a.innerHTML=`<img src="${v.thumb}" loading="lazy" onerror="this.style.display='none'">`;
        grid.appendChild(a);
      });
      d.appendChild(grid);
    }
  } else if(type==='done'){
    d.textContent='Selesai';
  } else if(type==='approval'){
    d.textContent=text;
  } else {
    d.textContent=text;
  }

  log.appendChild(d);
  log.scrollTop=log.scrollHeight;
}

function esc(s){return(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');}

function startPoll(){polling=true;poll();}

async function poll(){
  try{
    const r=await fetch('/poll?from='+lastLen);
    const data=await r.json();
    document.getElementById('hdr-model').textContent=
      (data.model||'').replace(/.*\//,'').replace(':free','');
    document.getElementById('stat-tokens').textContent=data.tokens+' tokens';
    document.getElementById('stat-cost').textContent='$'+data.cost;
    for(const e of data.entries){
      if(e.type==='approval'){
        document.getElementById('approval-desc').textContent=e.text;
        document.getElementById('approval-bar').style.display='block';
      }
      addMsg(e.type,e.text,e.extra);
      lastLen++;
    }
    if(!data.running){
      removeThinking();
      document.getElementById('send-btn').disabled=false;
      document.getElementById('approval-bar').style.display='none';
      setDot('green');
      polling=false;return;
    }
    setDot('yellow');
  }catch(e){}
  setTimeout(poll,800);
}

function setDot(c){
  const cl={'green':'#22c55e','yellow':'#f59e0b'};
  const dot=document.getElementById('hdr-dot');
  dot.style.background=cl[c];dot.style.boxShadow='0 0 8px '+cl[c];
}

(async()=>{
  const r=await fetch('/poll?from=0');
  const d=await r.json();
  document.getElementById('hdr-model').textContent=
    (d.model||'').replace(/.*\//,'').replace(':free','');
})();
</script>
</body>
</html>"""

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass

    def send_json(self, obj, code=200):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type","application/json")
        self.send_header("Content-Length",len(body))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        p = urlparse(self.path)
        if p.path == "/":
            body = HTML.encode()
            self.send_response(200)
            self.send_header("Content-Type","text/html;charset=utf-8")
            self.send_header("Content-Length",len(body))
            self.end_headers()
            self.wfile.write(body)
        elif p.path == "/poll":
            qs = parse_qs(p.query)
            from_idx = int(qs.get("from",["0"])[0])
            entries = sess.log[from_idx:]
            pending = sess.pending_tool
            self.send_json({
                "running": sess.running,
                "entries": entries,
                "model": sess.current_model,
                "tokens": sess.usage_stats["total_tokens"],
                "cost": f"{sess.usage_stats['cost_usd']:.4f}",
                "pending": {"desc": pending["desc"]} if pending else None,
            })
        else:
            self.send_response(404); self.end_headers()

    def do_POST(self):
        length = int(self.headers.get("Content-Length",0))
        body = json.loads(self.rfile.read(length))
        if self.path == "/send":
            if not sess.running:
                t = threading.Thread(target=run_agent, args=(body.get("text",""), body.get("image")), daemon=True)
                t.start()
            self.send_json({"ok":True})
        elif self.path == "/answer":
            if sess.pending_tool:
                sess.pending_tool["aq"].put(body["decision"])
            self.send_json({"ok":True})
        else:
            self.send_response(404); self.end_headers()


def main():
    if not core.OPENROUTER_API_KEY:
        sys.exit("ERROR: Set OPENROUTER_API_KEY dulu!\n  export OPENROUTER_API_KEY='sk-or-xxx'")
    port = int(os.environ.get("PORT","8080"))
    core.HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    add_log("info", f"🤖 Nexa Agent siap! Working dir: {sess.cwd}")
    print(f"✓ Web UI jalan di http://localhost:{port}")
    print("  Buka browser HP → http://localhost:8080")
    print("  Ctrl+C untuk stop.")
    HTTPServer(("0.0.0.0", port), Handler).serve_forever()

if __name__ == "__main__":
    main()
